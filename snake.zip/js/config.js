var config = { 
    "w":window.innerWidth, 
    "h":window.innerHeight, 
    "score":0,
    "level":1,
    "snakeSize":10,
    "direction":"right",
    "speed":0.2,
    "initialLength":4
}